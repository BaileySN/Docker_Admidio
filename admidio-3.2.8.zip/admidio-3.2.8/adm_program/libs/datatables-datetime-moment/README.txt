https://github.com/DataTables/Plugins/blob/master/sorting/datetime-moment.js
